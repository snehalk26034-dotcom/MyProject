import React from 'react'
import { Link } from 'react-router-dom'
import './App.css'
 
function Navbar() {
  return (
    <div className="navbar">
 
      <div className="logo">
        <img
          src="https://website-d45a5.firebaseapp.com/static/media/logo.ff1b89a6b41bdcdc6c64.png"
          alt="Kiran Dighe"
        />
      </div>
 
      <div className="nav-links">
        <Link className="active" to="/home">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/vendors">Vendors</Link>
        <Link to="/events">Events</Link>
        <Link to="/contact">Contact</Link>
 
        <button>Buy Tickets</button>
 
        <span>f</span>
        <span>◎</span>
        <span>in</span>
      </div>
 
    </div>
  )
}
 
export default Navbar